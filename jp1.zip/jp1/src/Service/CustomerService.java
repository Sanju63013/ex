package Service;

import model.Customer;

import java.util.ArrayList;

public class CustomerService {

    private static final CustomerService INSTANCE = new CustomerService();
    private CustomerService(){}
    ArrayList<Customer> customersList = new ArrayList<>();

    public static CustomerService getInstance() {
    return INSTANCE;
    }
    public void addCustomer(String firstName, String lastName, String email){
        Customer customer = new Customer(firstName, lastName, email);
        customersList.add(customer);
    }
    public Customer getCustomer(String customerEmail){
      Customer temp=null;
        for(Customer customer : customersList){

            if(customer.getEmail().equals(customerEmail)){
               temp=customer;
            }
        }
        return temp;
    }

    public ArrayList<Customer> getAllCustomers(){
        return customersList;
    }
}