package model;

public class Driver {

    public static void main(String[] args) {
        try
        {
            Customer customer=new Customer( "Jesh","Reddy","jeshreddy@gmail.com");
            Customer customer1=new Customer( "Jesh","Reddy","jeshre");
            System.out.println(customer);
        }
        catch ( IllegalArgumentException ex) {
            System.out.println(ex.getLocalizedMessage());
        }
    }
}
