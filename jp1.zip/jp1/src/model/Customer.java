package model;

import java.util.regex.Pattern;

public class Customer {
    private final String emailRegex = "^(.+)@(.+).(.+)$";
    private final Pattern pattern = Pattern.compile(emailRegex);
    private String firstName;
    private String lastName;
    private  String email;

    public Customer(String firstName, String lastName, String email)
    {
        if (!pattern.matcher(email).matches())
        {
            throw new IllegalArgumentException("Error,Invalid email");
        }
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;

    }
    public String getEmail() {

        return email;
    }

    public void setEmail(String email)
    {

        this.email = email;
    }
    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName)
    {

        this.firstName = firstName;
    }
    public String getLastName(String lastName) {

        return lastName;
    }

    public void setLastName(String lastNamel)

    {

        this.lastName = lastName;
    }

    @Override
    public String toString()
    {
        return "First Name: " + firstName
                + " Last Name: " + lastName
                + " Email: " + email;
    }
    //overriding equals method
    public boolean equals(Object obj){
        if(this==obj){
            return true;
        }
        else if(obj==null||obj.getClass()!=this.getClass()) {
            return false;
        }
        else{
            return false;
        }
    }
    public int hashCode(int value){
        return this.hashCode();
    }
}