import api.HotelResource;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class MainMenu {

    public static HotelResource hotelResource = HotelResource.getInstance();

    public static void findAndReserveARoom()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Check In date: (dd/mm/yyyy)");
        String checkInDateStr = scanner.nextLine();
        Date checkInDate = null;
        try
        {
            checkInDate = new SimpleDateFormat("dd/MM/yyyy").parse(checkInDateStr);
        }
        catch(ParseException ex)
        {
            System.out.println(ex.getLocalizedMessage());
            findAndReserveARoom();
        }
        System.out.println("Enter the Check Out date: (dd/mm/yyyy)");
        String checkOutDateStr = scanner.nextLine();
        Date checkOutDate = null;
        try
        {
            checkOutDate = new SimpleDateFormat("dd/MM/yyyy").parse(checkOutDateStr);
        }
        catch (ParseException ex)
        {
            System.out.println(ex.getLocalizedMessage());
            findAndReserveARoom();
        }
        if(checkInDate.after(checkOutDate)){
            System.out.println("Enter valid check In and check Out dates");
            findAndReserveARoom();
        }
        Collection<IRoom> availableRooms = hotelResource.findARoom(checkInDate,checkOutDate);

        Date alterCheckInDate = add7days(checkInDate);

        Date alterCheckOutDate = add7days(checkOutDate);
        if(availableRooms.isEmpty()){
            availableRooms=hotelResource.recommendedRooms(checkInDate,checkOutDate);
        }
        if(availableRooms.isEmpty())
        {
            System.out.println("Rooms were not available between "+ checkInDate+ " to " + checkOutDate + " finding after 7 days dates");
            Collection<IRoom> roomsForAlternateDates = hotelResource.recommendedRooms(alterCheckInDate,alterCheckOutDate);
            if(roomsForAlternateDates.isEmpty())
            {
                System.out.println("Rooms were not available after the next 7 days also");
                System.out.println("No room found,Hotel is fully booked");
                mainMenu();
            }
            else
            {
                System.out.println("Rooms found 7 days: Check-in Date: "+alterCheckInDate+" Check out date: "+ alterCheckOutDate);

                for (IRoom alterRoom:roomsForAlternateDates)
                {
                    System.out.println(alterRoom);
                }
                askForReserveRoom(alterCheckInDate,alterCheckOutDate,roomsForAlternateDates);
            }
        }
        else
        {
            System.out.println("Available are rooms: ");
            for (IRoom availableRoom:availableRooms)
            {
                System.out.println(availableRoom);
            }
            askForReserveRoom(checkInDate,checkOutDate,availableRooms);
        }
    }
    public static void askForReserveRoom(Date checkIn, Date checkOut, Collection<IRoom> rooms)
    {
        Scanner scanner = new Scanner(System.in);
        boolean flag = false;
        System.out.println("Do you want to reserve room y/n");
        char addRoom = scanner.next().charAt(0);
        while(addRoom != 'y' && addRoom != 'n') {
            System.out.println("Enter y or n");
            addRoom = scanner.next().charAt(0);
        }
        if(addRoom == 'y') {
            System.out.println("Did you have an account? y/n");
            char user = scanner.next().charAt(0);

            while(user != 'y' && user != 'n')
            {
                System.out.println("Enter y or n");

                user = scanner.next().charAt(0);
            }
            if(user == 'y')
            {
                System.out.println("Enter your email ID: ");
                String mail = scanner.next();

                if(hotelResource.getCustomer(mail)==null)
                {
                    System.out.println("Email not found in list, Create a new account");
                }
                else
                {
                    System.out.println("Enter room number to reserve: ");

                    String roomNo = scanner.next();

                    for(IRoom room:rooms)
                    {
                        if(room.getRoomNumber().equals(roomNo))
                        {
                            flag = true;
                            IRoom emptyRoom = hotelResource.getRoom(roomNo);
                            Reservation reservation = hotelResource.bookARoom(mail,emptyRoom,checkIn,checkOut);
                            System.out.println("Reservation is Completed Successfully!!");
                            System.out.println("----------------------");
                            System.out.println(reservation);
                            System.out.println("----------------------");
                        }
                    }
                    if(flag == false)
                    {
                        System.out.println("Entered room number is not available, Please select the valid room from list");
                        askForReserveRoom(checkIn,checkOut,rooms);
                    }
                }
                mainMenu();
            }
            else
            {
                System.out.println("Create an account");
                mainMenu();
            }
        }
        else if(addRoom == 'n')
        {
            mainMenu();
        }
        else
        {
            askForReserveRoom(checkIn,checkOut,rooms);
        }
    }
    public static Date add7days(Date date)
    {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE,7);
        return calendar.getTime();
    }
    public static void seeMyReservations()
    {
        Scanner scanner = new Scanner(System.in);
        Collection<Reservation> myReservations = Collections.emptyList();
        System.out.println("Enter mail ID: ");
        String email = scanner.nextLine();
        if(hotelResource.getCustomer(email) == null)
        {
            System.out.println("email you entered is not a valid email in this list, Create a new account");
            mainMenu();
        }
        try {
            myReservations = hotelResource.getCustomersReservations(email);
        }
        catch(IllegalArgumentException ex){
            System.out.println(ex.getLocalizedMessage());
            seeMyReservations();
        }
     //   if(myReservations==null)
     //   {
      //      System.out.println("No reservations is found");
      //      mainMenu();
     //   }
       // else
       // {
            for(Reservation reservation:myReservations)
            {
                System.out.println(reservation);
            }
            mainMenu();
        }

    public static void createAnAccount()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the email Id:");

        String email = scanner.nextLine();
        System.out.println("Enter the first name:");

        String fname = scanner.nextLine();
        System.out.println("Enter the last name:");
        String lname = scanner.nextLine();

        try
        {
            System.out.println(email+fname+lname);
            hotelResource.createACustomer(email,fname,lname);
            System.out.println("Customers account is created");
            mainMenu();
        }
        catch(IllegalArgumentException ex)
        {
            System.out.println(ex.getLocalizedMessage());
            mainMenu();
        }
    }
    public static void mainMenu() {
        System.out.println("WELCOME TO HOTEL RESERVATION APPLICATION");
        System.out.println("-------MAIN MENU---------");
        System.out.println("1. Find and reserve a room\n"+
                "2. See my reservations\n"+
                "3. Create an account\n"+
                "4. Admin\n"+
                "5. Exit");
        System.out.println("-----------------------");
        System.out.println("Select any option from the menu: ");
        Scanner scanner = new Scanner(System.in);
        String mainOpStr = scanner.nextLine();

        while(mainOpStr.length()!=1)
        {
            mainMenu();
        }
        String regex = "[1-5]+";
        Pattern p = Pattern.compile(regex);

        if(!p.matcher(mainOpStr).matches())
        {
            System.out.println("Option is not a valid,select valid option");
            mainMenu();
        }
        int mainOp = Integer.parseInt(mainOpStr);
        switch (mainOp) {
            case 1:
                findAndReserveARoom();
                break;
            case 2:
                seeMyReservations();
                break;
            case 3:
                createAnAccount();
                break;
            case 4:
                AdminMenu.adminMenu();
                break;
            case 5:
                System.out.println("Exit");
                break;
            default:
                System.out.println("Option is not valid,select valid option");
                break;
        }
    }

}