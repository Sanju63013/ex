package api;

import model.Customer;
import model.IRoom;
import Service.CustomerService;
import Service.ReservationService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AdminResource {
    private static final AdminResource INSTANCE = new AdminResource();
    private AdminResource(){}
    public static AdminResource getInstance(){
        return INSTANCE;
    }

    public Object getCustomer(String email){
        return CustomerService.getInstance().getCustomer(email);
    }
    public void addRoom(IRoom room){

            ReservationService.getInstance().addRoom(room);
    }

    public Collection<IRoom> getAllRooms(){

        return  ReservationService.getInstance().getAllRooms();
    }

    public ArrayList<Customer> getAllCustomers(){

        return CustomerService.getInstance().getAllCustomers();
    }

    public void displayAllReservations(){

        ReservationService.getInstance().printAllReservation();
    }
}