public class HotelReservation {
    public static void main(String[] args){
        MainMenu mainMenu = new MainMenu();
        mainMenu.mainMenu();
    }
}
