import api.AdminResource;
import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.util.*;
import java.util.regex.Pattern;

public class AdminMenu
{
    public static AdminResource adminResource = AdminResource.getInstance();
    public static void checkAllCustomers()
    {
        Collection<Customer> customerCollections = adminResource.getAllCustomers();

        if(customerCollections.isEmpty())
        {
            System.out.println("Customer list is empty");
            MainMenu.mainMenu();
        }
        else
        {
            for(Customer customer:customerCollections)
            {
                System.out.println(customer);
            }
            adminMenu();
        }
    }
    public static void checkAllRooms()
    {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        //   System.out.println(rooms);
        if(rooms.isEmpty())

        {
            System.out.println("No rooms are available");
            MainMenu.mainMenu();
        }
        else
        {
            for(IRoom room:rooms)
            {
                System.out.println(room);
            }
            adminMenu();
        }
    }
    public static void checkAllReservations()
    {
        adminResource.displayAllReservations();
        MainMenu.mainMenu();
    }
    public static void addARoom()
    {
        final String addRoomRegex = "([0-9]+).([0-9]+)";
        Pattern p = Pattern.compile(addRoomRegex);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter room number: ");

        String rNo = scanner.nextLine();
        System.out.println("Enter the room price per night:");

        String roomCostStr = scanner.next();

        if(!p.matcher(roomCostStr).matches())
        {
            System.out.println("Invalid price, enter valid ex: 00.00");
            addARoom();
        }
        double roomCost = Double.parseDouble(roomCostStr);
        System.out.println("enter the room type: single for single bed, double for double bed");
        String roomTypeStr = scanner.next();

        if(!(roomTypeStr.contentEquals("single")||roomTypeStr.contentEquals("double"))){
            System.out.println("Invalid room type, Please enter single or double");
            addARoom();
        }
        RoomType rType = RoomType.valueOf(roomTypeStr.toUpperCase());
        Room room = new Room(rNo,roomCost,rType);
        adminResource.addRoom(room);
        System.out.println("Room were added successfully");

        System.out.println("would you like to add another room y/n");

        String opinionStr = scanner.next();
        char opinion = opinionStr.charAt(0);

        while(opinion != 'y' && opinion != 'n')
        {
            System.out.println("Enter y or n");
            opinion = scanner.next().charAt(0);
        }
        if(opinion == 'y')
        {
            addARoom();
        }
        else if(opinion == 'n') {
            adminMenu();
        }
    }
    public static void adminMenu() {
        System.out.println("-------ADMIN MENU------");
        System.out.println("1. See all Customers\n" + "2. See all Rooms\n" + "3. See all Reservations\n" + "4. Add a Room\n" + "5. Back to Main Menu");
        System.out.println("--------------------");
        System.out.println("Select any option: ");
        Scanner scanner = new Scanner(System.in);
        String optionStr = scanner.nextLine();
        while(optionStr.length()!=1){
            System.out.println("Invalid, Enter a proper input");
            adminMenu();
        }
        final String regex = "[1-5]+";
        Pattern p = Pattern.compile(regex);

        if(!p.matcher(optionStr).matches())
        {
            System.out.println("Invalid,select a valid option");
            adminMenu();
        }
        int option = Integer.parseInt(optionStr);
        switch (option)
        {
            case 1:
                checkAllCustomers();
                break;
            case 2:
                checkAllRooms();
                break;
            case 3:
                checkAllReservations();
                break;
            case 4:
                addARoom();
                break;
            case 5:
                MainMenu.mainMenu();
                break;
            default:
                System.out.println("Your option is Invalid, Select the valid option");
                AdminMenu.adminMenu();
        }
    }
}